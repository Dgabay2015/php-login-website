<!DOCTYPE html>
<html lang="en">
  <head>
  <h1>You have signed in!</br> redirecting you to home page in 3 seconds!</h1>
  
  <meta http-equiv='refresh' content='4; url=http://lamp.cse.fau.edu/~dgabay2015/p7/php/index.php' />
  
  </head>